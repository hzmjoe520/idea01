CREATE PROCEDURE pro_inout(INOUT n VARCHAR(20))
  begin 
    select n;
    set n = "hello joe";
end;

