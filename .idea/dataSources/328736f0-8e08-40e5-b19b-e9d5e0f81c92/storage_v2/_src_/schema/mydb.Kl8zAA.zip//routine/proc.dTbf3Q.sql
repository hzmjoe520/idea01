CREATE PROCEDURE proc(IN n INT)
  begin
    declare v int;
     set v = n+1;
   case v
   when  0 then
    insert into account(name)values("a");
  when 1 then
     insert into account(name)values("b");
 else 
   insert into account(name)values("c");
  end case;
end;

