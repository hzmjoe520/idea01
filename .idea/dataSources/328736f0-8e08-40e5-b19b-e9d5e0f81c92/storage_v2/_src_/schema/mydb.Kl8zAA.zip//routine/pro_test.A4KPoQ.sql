CREATE PROCEDURE pro_test(IN num INT, OUT str VARCHAR(20))
  begin
   if num =60 then
        set str = "jige";
    elseif num =70 then
       set str = "lianghao";
     elseif num  = 80 then 
        set str ="youxiu";
      else
         set str= "good";
end if;
end;

